/* ============ CALENDAR ============ */
let calYear = 2026, calMonth = 4; // May 2026

function buildCalendar() {
  renderCalGrid();
  renderUpcoming();
}

function renderCalGrid() {
  const grid = document.getElementById('calGrid');
  const label = document.getElementById('calMonthLabel');
  if (!grid) return;

  label.textContent = MONTH_NAMES[calMonth] + ' ' + calYear;
  grid.innerHTML = '';

  const firstDay = new Date(calYear, calMonth, 1).getDay();
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const daysInPrev = new Date(calYear, calMonth, 0).getDate();
  const today = new Date();

  const postsThisMonth = state.posts.filter(p => {
    if (!p.date) return false;
    const [y, m] = p.date.split('-');
    return parseInt(y) === calYear && parseInt(m) - 1 === calMonth;
  });

  for (let i = 0; i < 42; i++) {
    const cell = document.createElement('div');
    cell.className = 'cal-cell';

    let day, mo = calMonth, yr = calYear, other = false;

    if (i < firstDay) {
      day = daysInPrev - firstDay + i + 1;
      mo = calMonth - 1; if (mo < 0) { mo = 11; yr--; }
      other = true;
    } else if (i >= firstDay + daysInMonth) {
      day = i - firstDay - daysInMonth + 1;
      mo = calMonth + 1; if (mo > 11) { mo = 0; yr++; }
      other = true;
    } else {
      day = i - firstDay + 1;
    }

    if (other) cell.classList.add('other-month');
    if (!other && day === today.getDate() && calMonth === today.getMonth() && calYear === today.getFullYear())
      cell.classList.add('today');

    cell.innerHTML = `<div class="cell-num">${day}</div>`;

    if (!other) {
      const dayPosts = postsThisMonth.filter(p => parseInt(p.date.split('-')[2]) === day);
      dayPosts.slice(0, 3).forEach(p => {
        const pf = PLATFORM_COLORS[p.platform] || {};
        const pill = document.createElement('div');
        pill.className = 'cal-post-pill ' + (pf.pill || '');
        pill.textContent = p.title;
        pill.title = p.title + ' — ' + p.status;
        pill.onclick = (e) => { e.stopPropagation(); showPostModal(p.id); };
        cell.appendChild(pill);
      });
      if (dayPosts.length > 3) {
        const more = document.createElement('div');
        more.className = 'pill-more';
        more.textContent = '+' + (dayPosts.length - 3) + ' more';
        cell.appendChild(more);
      }

      const dateStr = `${calYear}-${String(calMonth+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
      cell.onclick = () => {
        document.querySelectorAll('.cal-cell').forEach(c => c.classList.remove('selected'));
        cell.classList.add('selected');
        document.getElementById('quickPostDate').value = dateStr;
      };
    }

    grid.appendChild(cell);
  }
}

function renderUpcoming() {
  const list = document.getElementById('upcomingList');
  if (!list) return;
  const upcoming = state.posts
    .filter(p => p.date && p.status !== 'published')
    .sort((a, b) => a.date > b.date ? 1 : -1)
    .slice(0, 6);

  list.innerHTML = upcoming.map(p => {
    const pf = PLATFORM_COLORS[p.platform] || {};
    const st = STATUS_MAP[p.status] || {};
    return `<div class="upcoming-item">
      <div class="upcoming-date">${fmtDate(p.date)} · ${p.platform}</div>
      <div class="upcoming-title">${p.icon || pf.icon || ''} ${p.title}</div>
      <span class="badge ${st.cls}">${st.label}</span>
    </div>`;
  }).join('') || '<div style="color:var(--text3);font-size:12px">No upcoming posts</div>';
}

function changeMonth(d) {
  calMonth += d;
  if (calMonth > 11) { calMonth = 0; calYear++; }
  if (calMonth < 0) { calMonth = 11; calYear--; }
  buildCalendar();
}

function goToday() {
  const now = new Date();
  calYear = now.getFullYear();
  calMonth = now.getMonth();
  buildCalendar();
}

function setCalView(v, el) {
  document.querySelectorAll('.vtbtn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  // week view could be extended here
}

function quickAdd() {
  const title = document.getElementById('quickPostTitle').value.trim();
  const date = document.getElementById('quickPostDate').value;
  const platform = document.getElementById('quickPostPlatform').value;
  if (!title || !date) { showToast('Enter a title and date', 'error'); return; }
  const post = { id: genId(), title, platform, date, time: state.settings.defaultTime || '09:00', status: 'draft', type: 'Image post', caption: '', hashtags: '', brief: '', assignee: '', priority: 'normal', notes: '', platforms: [platform], created: new Date().toISOString().split('T')[0] };
  state.posts.push(post);
  saveState();
  document.getElementById('quickPostTitle').value = '';
  buildCalendar();
  updateBadge();
  showToast('Post added to calendar!', 'success');
}

function showPostModal(id) {
  const p = state.posts.find(x => x.id === id);
  if (!p) return;
  const pf = PLATFORM_COLORS[p.platform] || {};
  const st = STATUS_MAP[p.status] || {};
  document.getElementById('modalTitle').textContent = p.title;
  document.getElementById('modalBody').innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
      <div class="platform-icon" style="background:${pf.bg}">${pf.icon}</div>
      <div>
        <div style="font-size:13px;font-weight:600">${p.platform}</div>
        <div style="font-size:11px;color:var(--text3)">${fmtDate(p.date)} at ${p.time || ''}</div>
      </div>
      <span class="badge ${st.cls}" style="margin-left:auto">${st.label}</span>
    </div>
    <div class="form-group"><label class="form-label">Caption</label>
      <div style="background:var(--surface2);border-radius:var(--radius);padding:10px;font-size:13px;line-height:1.6;color:var(--text)">${p.caption || '<em style="color:var(--text3)">No caption</em>'}</div>
    </div>
    ${p.assignee ? `<div class="form-group"><label class="form-label">Assigned to</label><div style="font-size:13px;color:var(--text)">${p.assignee}</div></div>` : ''}
    ${p.notes ? `<div class="form-group"><label class="form-label">Notes</label><div style="font-size:13px;color:var(--text2)">${p.notes}</div></div>` : ''}
  `;
  document.getElementById('modalFooter').innerHTML = `
    <button class="btn btn-ghost" onclick="closeModal()">Close</button>
    <button class="btn" onclick="editPostById(${id});closeModal()">Edit post</button>
  `;
  document.getElementById('modalOverlay').classList.add('open');
}

function editPostById(id) {
  navigate('create', document.querySelector('.nav-item[data-view="create"]'));
  setTimeout(() => loadPostIntoForm(id), 50);
}
