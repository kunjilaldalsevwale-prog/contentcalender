/* ============================================
   APP CORE — navigation, sidebar, toast
   ============================================ */

let currentView = 'calendar';
let sidebarCollapsed = false;

const VIEW_TITLES = {
  calendar: 'Calendar',
  posts: 'Posts',
  create: 'Create Post',
  meta: 'Meta Ads',
  whatsapp: 'WhatsApp Marketing',
  agenda: 'Monthly Agenda',
  analytics: 'Analytics',
  team: 'Team',
  settings: 'Settings',
};

function navigate(view, el) {
  // deactivate old
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  // activate new
  const viewEl = document.getElementById('view-' + view);
  if (viewEl) viewEl.classList.add('active');
  if (el) el.classList.add('active');

  document.getElementById('pageTitle').textContent = VIEW_TITLES[view] || view;
  currentView = view;

  // render on first visit
  const renders = {
    calendar: buildCalendar,
    posts: renderPosts,
    meta: renderMetaAds,
    whatsapp: renderWhatsApp,
    agenda: renderAgenda,
    analytics: renderAnalytics,
    team: renderTeam,
    settings: renderSettings,
  };
  if (renders[view]) renders[view]();

  // update badge
  updateBadge();
}

function updateBadge() {
  const drafts = state.posts.filter(p => p.status === 'draft' || p.status === 'review').length;
  const badge = document.getElementById('badge-posts');
  if (badge) { badge.textContent = drafts; badge.style.display = drafts ? '' : 'none'; }
}

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  if (window.innerWidth <= 640) {
    sidebar.classList.toggle('mobile-open');
  } else {
    sidebarCollapsed = !sidebarCollapsed;
    sidebar.classList.toggle('collapsed', sidebarCollapsed);
    document.getElementById('sidebarToggle').textContent = sidebarCollapsed ? '›' : '‹';
  }
}

document.getElementById('sidebarToggle').addEventListener('click', toggleSidebar);

// Global search
function globalSearch(q) {
  if (!q.trim()) return;
  navigate('posts', document.querySelector('.nav-item[data-view="posts"]'));
  setTimeout(() => {
    const filtered = state.posts.filter(p =>
      p.title.toLowerCase().includes(q.toLowerCase()) ||
      p.caption.toLowerCase().includes(q.toLowerCase())
    );
    renderPostCards(filtered);
  }, 50);
}

// Toast
let toastTimer = null;
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

// Export
function exportData() {
  const data = JSON.stringify(state.posts, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'socialhub-posts.json';
  a.click();
  showToast('Posts exported!', 'success');
}

// Init
window.addEventListener('DOMContentLoaded', () => {
  navigate('calendar', document.querySelector('.nav-item[data-view="calendar"]'));
  updateBadge();
  // set today's date as default in create form
  const today = new Date().toISOString().split('T')[0];
  const createDate = document.getElementById('createDate');
  if (createDate) createDate.value = today;
  const quickDate = document.getElementById('quickPostDate');
  if (quickDate) quickDate.value = today;
});
