/* ============================================
   DATA STORE — localStorage persistence
   ============================================ */

const DB = {
  _key: 'socialhub_v1',

  defaults: {
    posts: [
      { id: 1, title: 'Summer sale launch reel', platform: 'Instagram', date: '2026-05-08', time: '10:00', status: 'scheduled', type: 'Video / Reel', caption: 'Summer is here and so is our biggest sale yet! 🌞 Up to 40% off everything. Swipe to explore 👉 #SummerSale #Fashion #Style', hashtags: '#SummerSale #Fashion #Style', brief: 'Upbeat reel showcasing the new collection with music', assignee: 'Priya Sharma', priority: 'high', notes: 'Use trending audio from IG library', platforms: ['Instagram'], created: '2026-04-28' },
      { id: 2, title: 'Product teaser — new collection', platform: 'Instagram', date: '2026-05-05', time: '09:00', status: 'scheduled', type: 'Image post', caption: 'Something exciting is coming… 👀 Stay tuned for our biggest drop this season. #ComingSoon #NewCollection', hashtags: '#ComingSoon #NewCollection', brief: 'Mysterious teaser image with dark background', assignee: 'Arjun Mehta', priority: 'normal', notes: '', platforms: ['Instagram'], created: '2026-04-25' },
      { id: 3, title: 'Facebook sale kick-off', platform: 'Facebook', date: '2026-05-08', time: '11:00', status: 'review', type: 'Image post', caption: 'Big news, friends! Our Summer Sale starts today with deals you cannot miss. Shop now → bit.ly/sale26', hashtags: '#SummerSale', brief: 'Bright colorful banner with sale percentage', assignee: 'Priya Sharma', priority: 'high', notes: 'Needs legal sign-off on offer terms', platforms: ['Facebook'], created: '2026-04-26' },
      { id: 4, title: 'WhatsApp May newsletter', platform: 'WhatsApp', date: '2026-05-12', time: '10:00', status: 'draft', type: 'Text only', caption: 'Hey [Name]! May edition is here 🌸 Check out what\'s new this month and grab your exclusive member discount.', hashtags: '', brief: 'Friendly personal tone, 3 paragraphs max', assignee: 'Neha Gupta', priority: 'normal', notes: '', platforms: ['WhatsApp'], created: '2026-04-30' },
      { id: 5, title: 'Mid-month engagement', platform: 'Twitter/X', date: '2026-05-15', time: '12:00', status: 'draft', type: 'Text only', caption: 'Quick poll: what\'s your go-to summer look? 🏖 Drop a reply below 👇 #SummerStyle', hashtags: '#SummerStyle', brief: 'Short punchy tweet with emoji to drive engagement', assignee: '', priority: 'normal', notes: '', platforms: ['Twitter/X'], created: '2026-05-01' },
      { id: 6, title: 'Behind the scenes story', platform: 'Instagram', date: '2026-05-20', time: '16:00', status: 'draft', type: 'Story', caption: 'A little look at how the magic happens ✨ Our team works so hard to bring you the best. #BTS #TeamWork', hashtags: '#BTS #TeamWork', brief: 'Candid photos from the studio / workspace', assignee: 'Arjun Mehta', priority: 'normal', notes: '', platforms: ['Instagram'], created: '2026-05-02' },
      { id: 7, title: 'Spring lookbook post', platform: 'Facebook', date: '2026-04-28', time: '10:00', status: 'published', type: 'Carousel', caption: 'Our spring lookbook is out! 🌸 Every piece is designed with love. Which look is your favourite?', hashtags: '#SpringLookbook', brief: '', assignee: 'Priya Sharma', priority: 'normal', notes: '', platforms: ['Facebook'], created: '2026-04-20' },
      { id: 8, title: 'LinkedIn thought leadership', platform: 'LinkedIn', date: '2026-05-22', time: '09:00', status: 'scheduled', type: 'Text only', caption: '5 lessons we learned growing our brand on social media 📈 Thread below 👇', hashtags: '#Marketing #SocialMedia', brief: 'Professional informative tone', assignee: 'Neha Gupta', priority: 'high', notes: '', platforms: ['LinkedIn'], created: '2026-05-01' },
    ],
    ads: [
      { id: 1, title: 'Summer Sale — Conversion', type: 'Conversion Campaign', objective: 'Purchases', audience: 'Women 18–35, Tier-1 cities', budget: 15000, spent: 9200, reach: 48200, clicks: 1240, ctr: '2.57', cpc: '7.42', status: 'active' },
      { id: 2, title: 'Brand Awareness — Reels', type: 'Awareness Campaign', objective: 'Impressions', audience: 'All genders 18–45', budget: 8000, spent: 3500, reach: 92400, clicks: 460, ctr: '0.50', cpc: '7.61', status: 'active' },
      { id: 3, title: 'Retargeting — Cart visitors', type: 'Retargeting', objective: 'Add to cart', audience: 'Website visitors (30d)', budget: 6000, spent: 5800, reach: 12100, clicks: 890, ctr: '7.35', cpc: '6.52', status: 'active' },
      { id: 4, title: 'New Collection Launch', type: 'Traffic Campaign', objective: 'Link clicks', audience: 'Lookalike 2%', budget: 10000, spent: 2100, reach: 31000, clicks: 620, ctr: '2.00', cpc: '3.39', status: 'paused' },
    ],
    waContacts: [
      { id: 1, name: 'Customers Group', sub: '324 members', initials: 'CG', color: '#EAF3DE', textColor: '#27500A', lastMsg: '🎉 Summer sale is live!', time: '10:24', type: 'group' },
      { id: 2, name: 'VIP Members', sub: '87 members', initials: 'VIP', color: '#EEEDFE', textColor: '#3C3489', lastMsg: 'Early access link sent', time: 'Yesterday', type: 'group' },
      { id: 3, name: 'Newsletter Subscribers', sub: '512 contacts', initials: 'NL', color: '#FAEEDA', textColor: '#633806', lastMsg: 'May edition draft', time: 'May 1', type: 'broadcast' },
      { id: 4, name: 'Re-engagement List', sub: '203 contacts', initials: 'RE', color: '#FBEAF0', textColor: '#72243E', lastMsg: 'We miss you! 👋', time: 'Apr 28', type: 'broadcast' },
    ],
    waMessages: {
      1: [
        { id: 1, text: 'Hey, when is the summer sale starting? 👀', type: 'recv', time: '9:45 AM' },
        { id: 2, text: 'Summer sale is live NOW! 🎉 Get up to 40% off on all items. Tap the link to shop: bit.ly/sale2026', type: 'sent', time: '10:24 AM' },
        { id: 3, text: 'Amazing! Thank you 🙌', type: 'recv', time: '10:26 AM' },
      ],
      2: [
        { id: 1, text: 'Welcome to the VIP club! 🌟 You have early access to the new collection.', type: 'sent', time: 'Yesterday 9:00 AM' },
        { id: 2, text: 'Thank you so much! Excited to see it 😍', type: 'recv', time: 'Yesterday 9:05 AM' },
      ],
      3: [],
      4: [],
    },
    goals: [
      { id: 1, title: 'Brand awareness campaign', desc: 'Launch the summer collection with 3 reels and a paid Meta campaign targeting 18–35 audience in tier-1 cities.', progress: 60, color: '#7F77DD' },
      { id: 2, title: 'WhatsApp subscriber growth', desc: 'Grow WhatsApp marketing list to 1,000 subscribers with opt-in landing page and broadcast campaign.', progress: 42, color: '#639922' },
      { id: 3, title: 'Instagram engagement target', desc: 'Achieve 5% engagement rate on Instagram with consistent posting (4× per week) and story polls.', progress: 75, color: '#BA7517' },
    ],
    agendaEvents: [
      { id: 1, title: 'Summer sale Meta ad campaign goes live', sub: 'Paid campaign · all ad sets active', day: '8', month: 'May', color: '#7F77DD' },
      { id: 2, title: 'WhatsApp broadcast — May edition', sub: 'Newsletter blast to all subscribers', day: '12', month: 'May', color: '#639922' },
      { id: 3, title: 'Mid-month content review with team', sub: 'Weekly sync · 60 min', day: '15', month: 'May', color: '#BA7517' },
      { id: 4, title: 'Instagram reel — behind the scenes', sub: 'Film & edit day', day: '20', month: 'May', color: '#7F77DD' },
      { id: 5, title: 'End of month performance report', sub: 'Analytics & learnings', day: '31', month: 'May', color: '#A32D2D' },
    ],
    team: [
      { id: 1, name: 'Priya Sharma', role: 'Content Lead', initials: 'PS', color: '#EEEDFE', textColor: '#3C3489', email: 'priya@brand.com', posts: 12, drafts: 3 },
      { id: 2, name: 'Arjun Mehta', role: 'Designer', initials: 'AM', color: '#EAF3DE', textColor: '#27500A', email: 'arjun@brand.com', posts: 8, drafts: 2 },
      { id: 3, name: 'Neha Gupta', role: 'Strategist', initials: 'NG', color: '#FAEEDA', textColor: '#633806', email: 'neha@brand.com', posts: 5, drafts: 1 },
      { id: 4, name: 'Rahul Das', role: 'Paid Ads Manager', initials: 'RD', color: '#FBEAF0', textColor: '#72243E', email: 'rahul@brand.com', posts: 2, drafts: 0 },
    ],
    settings: {
      brandName: 'Your Brand', industry: 'Fashion & Apparel',
      timezone: 'Asia/Kolkata (IST)', defaultTime: '09:00',
    },
    notes: '',
  },

  load() {
    try {
      const raw = localStorage.getItem(this._key);
      if (raw) { const d = JSON.parse(raw); return { ...this.defaults, ...d }; }
    } catch(e) {}
    return { ...this.defaults };
  },

  save(data) {
    try { localStorage.setItem(this._key, JSON.stringify(data)); } catch(e) {}
  },

  clear() {
    localStorage.removeItem(this._key);
  }
};

// Global state
const state = DB.load();

function saveState() { DB.save(state); }

// Platform helpers
const PLATFORM_COLORS = {
  Instagram: { bg: '#FBEAF0', text: '#993556', pill: 'pill-ig', chip: 'chip-ig', icon: '📸' },
  Facebook:  { bg: '#E6F1FB', text: '#185FA5', pill: 'pill-fb', chip: 'chip-fb', icon: '📘' },
  WhatsApp:  { bg: '#EAF3DE', text: '#3B6D11', pill: 'pill-wa', chip: 'chip-wa', icon: '💬' },
  'Twitter/X': { bg: '#E1F5EE', text: '#0F6E56', pill: 'pill-tw', chip: 'chip-tw', icon: '🐦' },
  LinkedIn:  { bg: '#E6F1FB', text: '#185FA5', pill: 'pill-li', chip: 'chip-li', icon: '💼' },
  'Meta Ad': { bg: '#EEEDFE', text: '#3C3489', pill: 'pill-meta', chip: 'chip-meta', icon: '📊' },
};

const STATUS_MAP = {
  draft: { label: 'Draft', cls: 'badge-draft' },
  scheduled: { label: 'Scheduled', cls: 'badge-scheduled' },
  review: { label: 'In Review', cls: 'badge-review' },
  published: { label: 'Published', cls: 'badge-published' },
};

const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const SHORT_MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function fmtDate(dateStr) {
  if (!dateStr) return '';
  const [y, m, d] = dateStr.split('-');
  return `${SHORT_MONTHS[parseInt(m)-1]} ${parseInt(d)}, ${y}`;
}

function genId() { return Date.now() + Math.floor(Math.random()*1000); }
